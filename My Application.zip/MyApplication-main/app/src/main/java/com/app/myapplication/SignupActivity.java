package com.app.myapplication;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.app.myapplication.utils.Constants;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;
import pl.aprilapps.easyphotopicker.ChooserType;
import pl.aprilapps.easyphotopicker.EasyImage;
import pl.aprilapps.easyphotopicker.MediaFile;
import pl.aprilapps.easyphotopicker.MediaSource;

public class SignupActivity extends AppCompatActivity {

    MaterialButton registerbutton;
    TextInputEditText signupemail, signuppass, name, phone;
    FirebaseAuth auth;
    FirebaseFirestore firestore;
    FirebaseStorage storage;
    StorageReference storageReference;
    CircleImageView profilePic;
    ImageView cameraBtn;

    EasyImage easyImage;

    Uri profileImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Initialize UI elements
        registerbutton = this.findViewById(R.id.register_btn);
        signupemail = this.findViewById(R.id.email);
        signuppass = this.findViewById(R.id.password);
        name = this.findViewById(R.id.name);
        phone = this.findViewById(R.id.phone);
        profilePic = this.findViewById(R.id.profile_pic);
        cameraBtn = this.findViewById(R.id.camera_btn);

        auth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();

        easyImage = new EasyImage.Builder(this)
                .setChooserTitle("Pick Profile Image")
                .setChooserType(ChooserType.CAMERA_AND_GALLERY)
                .allowMultiple(false)
                .build();

        // Camera button click listener
        cameraBtn.setOnClickListener(v -> {
            // Show alert dialog to let the user choose between Camera or Gallery
            showImageSourceDialog();
        });

        registerbutton.setOnClickListener(v -> signUpUser());
    }

    private void showImageSourceDialog() {
        // Inflate the custom layout
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialogbox, null);

        // Build the dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);

        // Find buttons in the custom layout
        Button buttonCamera = dialogView.findViewById(R.id.button_camera);
        Button buttonGallery = dialogView.findViewById(R.id.button_gallery);
        AlertDialog dialog = builder.create();
        dialog.show();

        // Set up button click listeners
        buttonCamera.setOnClickListener(v -> {
            easyImage.openCameraForImage(SignupActivity.this);
            dialog.dismiss();
        });

        buttonGallery.setOnClickListener(v -> {
            easyImage.openGallery(SignupActivity.this);
            dialog.dismiss();
        });

        // Create and show the dialog

    }


    private void signUpUser() {
        String email = signupemail.getText().toString();
        String password = signuppass.getText().toString();
        String name = this.name.getText().toString();
        String phone = this.phone.getText().toString();

        if (email.isEmpty()) {
            Toast.makeText(SignupActivity.this, "Email is empty.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (password.isEmpty() || password.length() < 8) {
            Toast.makeText(SignupActivity.this, "Either password is empty or less than 8 characters", Toast.LENGTH_SHORT).show();
            return;
        }

        auth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener(authResult -> {
                    if (profileImage == null) {
                        saveUserDataWithoutImage(authResult.getUser().getUid(), email, name, phone);
                    } else {
                        saveUserDataWithImage(authResult.getUser().getUid(), email, name, phone);
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(SignupActivity.this, e.toString(), Toast.LENGTH_SHORT).show());
    }

    private void saveUserDataWithoutImage(String uid, String email, String name, String phone) {
        Map<String, Object> map = new HashMap<>();
        map.put("id", uid);
        map.put("name", name);
        map.put("phone", phone);
        map.put("email", email);

        firestore.collection(Constants.usersCollection).document(uid).set(map)
                .addOnSuccessListener(unused -> {
                    Toast.makeText(SignupActivity.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(SignupActivity.this, HomeActivity.class));
                })
                .addOnFailureListener(e -> Toast.makeText(SignupActivity.this, e.toString(), Toast.LENGTH_SHORT).show());
    }

    private void saveUserDataWithImage(String uid, String email, String name, String phone) {
        String fileName = "Images/" + uid + ".png";
        StorageReference imageRef = storageReference.child(fileName);

        imageRef.putFile(profileImage)
                .addOnSuccessListener(taskSnapshot -> imageRef.getDownloadUrl()
                        .addOnSuccessListener(uri -> {
                            Map<String, Object> map = new HashMap<>();
                            map.put("id", uid);
                            map.put("name", name);
                            map.put("phone", phone);
                            map.put("email", email);
                            map.put("image", uri.toString());

                            firestore.collection(Constants.usersCollection).document(uid).set(map)
                                    .addOnSuccessListener(unused -> {
                                        Toast.makeText(SignupActivity.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                                        startActivity(new Intent(SignupActivity.this, HomeActivity.class));
                                    })
                                    .addOnFailureListener(e -> Toast.makeText(SignupActivity.this, e.toString(), Toast.LENGTH_SHORT).show());
                        })
                        .addOnFailureListener(e -> Toast.makeText(SignupActivity.this, e.toString(), Toast.LENGTH_SHORT).show()))
                .addOnFailureListener(e -> Toast.makeText(SignupActivity.this, e.toString(), Toast.LENGTH_SHORT).show());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        easyImage.handleActivityResult(requestCode, resultCode, data, this, new EasyImage.Callbacks() {
            @Override
            public void onImagePickerError(@NonNull Throwable throwable, @NonNull MediaSource mediaSource) {
                // Handle error
            }

            @Override
            public void onMediaFilesPicked(@NonNull MediaFile[] mediaFiles, @NonNull MediaSource mediaSource) {
                // Set the picked image as profile picture
                profileImage = Uri.fromFile(mediaFiles[0].getFile());
                Glide.with(SignupActivity.this).load(profileImage).into(profilePic);
            }

            @Override
            public void onCanceled(@NonNull MediaSource mediaSource) {
                // Handle cancel action
            }
        });
    }
}
