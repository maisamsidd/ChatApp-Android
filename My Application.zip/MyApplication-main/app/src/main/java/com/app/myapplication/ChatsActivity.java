package com.app.myapplication;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.app.myapplication.adapters.ChatListAdapter;
import com.app.myapplication.models.Channel;
import com.app.myapplication.models.Chat;
import com.app.myapplication.utils.Constants;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ChatsActivity extends AppCompatActivity {

    Channel channel;

    TextView userName;
    ImageButton backBtn;

    RecyclerView chatListView;
    ChatListAdapter adapter;
    ArrayList<Chat> chats;

    FirebaseFirestore firestore;
    FloatingActionButton sendButton;
    TextInputEditText sendMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        channel = (Channel) getIntent().getSerializableExtra("channel");
        setContentView(R.layout.activity_chats);

        firestore = FirebaseFirestore.getInstance();

        chats = new ArrayList<>();

        userName = this.findViewById(R.id.user_name);
        backBtn = this.findViewById(R.id.back_btn);
        chatListView = this.findViewById(R.id.chat_list_view);
        sendButton = this.findViewById(R.id.sendbtn);
        sendMessage = this.findViewById(R.id.sendMessage);

        chatListView.setLayoutManager(new LinearLayoutManager(this));



        getChats();

        backBtn.setOnClickListener(v -> finish());
        sendButton.setOnClickListener(v ->   sendMessage());

    }

    public void getChats(){

        firestore.collection(Constants.channelsCollection).document(channel.getChannelId())
                .collection(Constants.chatsCollection).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {

                    for(DocumentSnapshot snapshot : queryDocumentSnapshots.getDocuments()){

                        chats.add(snapshot.toObject(Chat.class));
                    }

                    adapter = new ChatListAdapter(this, chats);
                    chatListView.setAdapter(adapter);

                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                });
    }
    public void sendMessage(){
        String sendMsg = this.sendMessage.getText().toString();


        if(!sendMsg.isEmpty()){

            Map<String, Object> messageData = new HashMap<>();
            messageData.put("message", sendMsg);
            messageData.put("sender", channel.getUser().getName()); // Or get the current user's ID
            messageData.put("timestamp", System.currentTimeMillis());


            firestore.collection(Constants.channelsCollection)
                    .document(channel.getChannelId())
                    .collection(Constants.chatsCollection)
                    .add(messageData)
                    .addOnSuccessListener(documentReference -> {
                        Toast.makeText(this, "Message sent", Toast.LENGTH_SHORT).show();
                        sendMessage.setText("");
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Error sending message: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        } else {
            Toast.makeText(this, "Message cannot be empty", Toast.LENGTH_SHORT).show();
        }
    }


}