package com.app.myapplication.utils;

public class Constants {

    public static String usersCollection = "users";
    public static String channelsCollection = "channels";
    public static String chatsCollection = "chats";
}
