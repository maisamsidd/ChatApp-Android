package com.app.myapplication;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.app.myapplication.ChatsActivity;
import com.app.myapplication.LoginActivity;
import com.app.myapplication.R;
import com.app.myapplication.adapters.ChannelListAdapter;
import com.app.myapplication.models.Channel;
import com.app.myapplication.models.User;
import com.app.myapplication.utils.Constants;
import com.app.myapplication.utils.PrefUtils;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity {

    User user;
    PrefUtils pref;
    RecyclerView channelListView;
    ChannelListAdapter adapter;
    ArrayList<Channel> channels;
    FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        user = (User) getIntent().getSerializableExtra("user");
        setContentView(R.layout.activity_home);

        firestore = FirebaseFirestore.getInstance();
        pref = PrefUtils.getInstance(this);
        channels = new ArrayList<>();
        channelListView = this.findViewById(R.id.channel_list_view);
        channelListView.setLayoutManager(new LinearLayoutManager(this));

        getChannels();

        // Implement the custom logout dialog here
        findViewById(R.id.logout_btn).setOnClickListener(view -> showLogoutDialog());
    }

    // Method to display the custom logout dialog
    private void showLogoutDialog() {
        // Inflate the custom dialog layout
        View dialogView = LayoutInflater.from(this).inflate(R.layout.logout, null);

        // Create and set up the dialog
        Dialog dialog = new Dialog(this);
        dialog.setContentView(dialogView);

        // Set Cancel button click listener
        Button cancelBtn = dialogView.findViewById(R.id.cancel);
        cancelBtn.setOnClickListener(v -> dialog.dismiss());

        // Set Logout button click listener
        Button logoutBtn = dialogView.findViewById(R.id.logout);
        logoutBtn.setOnClickListener(v -> {
            // Perform logout
            if (pref.clearPrefs()) {
                Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            } else {
                Toast.makeText(HomeActivity.this, "Unable to logout. Please try again!", Toast.LENGTH_SHORT).show();
            }
            dialog.dismiss();
        });

        // Show the dialog
        dialog.show();
    }

    // Fetching the list of channels (this part remains the same)
    public void getChannels() {
        firestore.collection(Constants.channelsCollection).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    for (DocumentSnapshot snapshot : queryDocumentSnapshots.getDocuments()) {
                        ArrayList<String> userIds = (ArrayList<String>) snapshot.get("userIds");
                        String otherId = userIds.stream()
                                .filter(id -> !id.equals(pref.getUser().getId()))
                                .findFirst().orElse(null);
                        if (otherId != null) {
                            firestore.collection(Constants.usersCollection).document(otherId).get()
                                    .addOnSuccessListener(documentSnapshot -> {
                                        User user = documentSnapshot.toObject(User.class);
                                        Channel channel = snapshot.toObject(Channel.class);
                                        channel.setUser(user);
                                        channels.add(channel);
                                        adapter.notifyItemChanged(channels.size() - 1);
                                        channels.sort((a, b) -> b.getCreatedAt().compareTo(a.getCreatedAt()));
                                    })
                                    .addOnFailureListener(e -> Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show());
                        }
                    }
                    adapter = new ChannelListAdapter(this, channels);
                    channelListView.setAdapter(adapter);
                    adapter.setOnChannelClickListener(position -> {
                        Intent intent = new Intent(HomeActivity.this, ChatsActivity.class);
                        intent.putExtra("channel", channels.get(position));
                        startActivity(intent);
                    });
                })
                .addOnFailureListener(e -> Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}
